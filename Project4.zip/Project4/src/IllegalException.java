public class IllegalException extends IllegalArgumentException {
	public IllegalException(String message) {
		super(message);
	}

	public Object getMessage(String string) {
		// TODO Auto-generated method stub
		return null;
	}
}
